from django.apps import AppConfig


class StormConfig(AppConfig):
    name = 'storm'
