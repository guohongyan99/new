from django.apps import AppConfig


class Oauth1Config(AppConfig):
    name ='oauth'
